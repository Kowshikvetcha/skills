"""
LLM Client — Model-Agnostic Python Integration
===============================================
This file is auto-generated. Do NOT edit it.

Configuration:
  - API key  → .env          (AI_API_KEY=...)
  - Settings → llm_config.yaml (provider, model, temperature, etc.)

Usage:
    from llm_client import LLMClient
    client = LLMClient()
    print(client.chat("Hello!"))
"""

import os
import yaml
from pathlib import Path
from dotenv import load_dotenv
from openai import OpenAI


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_PROVIDER_DEFAULTS = {
    "openai":       "gpt-4o-mini",
    "anthropic":    "claude-3-5-haiku-20241022",
    "gemini":       "gemini-1.5-flash",
    "mistral":      "mistral-small-latest",
    "groq":         "llama-3.1-8b-instant",
    "ollama":       "llama3.2",
    "openrouter":   "mistralai/mistral-7b-instruct",
    "huggingface":  "microsoft/DialoGPT-medium",
}


def _load_config() -> dict:
    """
    Load API key from .env and LLM settings from llm_config.yaml.
    Both files must be in the same directory as this script or the working directory.
    """
    # Load .env — injects AI_API_KEY into os.environ
    env_path = Path(__file__).parent / ".env"
    load_dotenv(dotenv_path=env_path)

    api_key = os.getenv("AI_API_KEY", "").strip()
    if not api_key:
        raise ValueError(
            "AI_API_KEY not found.\n"
            "Make sure .env exists in the same folder and contains:\n"
            "  AI_API_KEY=your-key-here"
        )

    # Load llm_config.yaml
    config_path = Path(__file__).parent / "llm_config.yaml"
    if not config_path.exists():
        raise FileNotFoundError(
            f"llm_config.yaml not found at {config_path}.\n"
            "Create it with at least:\n"
            "  provider: openai"
        )

    with open(config_path) as f:
        config = yaml.safe_load(f) or {}

    provider = config.get("provider", "").strip().lower()
    if not provider:
        raise ValueError(
            "'provider' field is missing from llm_config.yaml.\n"
            f"Supported providers: {list(_PROVIDER_DEFAULTS.keys())}"
        )

    return {
        "api_key":       api_key,
        "provider":      provider,
        "model":         config.get("model"),           # None → use built-in default
        "temperature":   float(config.get("temperature", 0.7)),
        "max_tokens":    int(config.get("max_tokens", 1024)),
        "system_prompt": config.get("system_prompt", "You are a helpful assistant."),
    }


# ---------------------------------------------------------------------------
# LLMClient
# ---------------------------------------------------------------------------

class LLMClient:
    """
    Model-agnostic LLM client. Reads all configuration automatically from:
      .env            → AI_API_KEY
      llm_config.yaml → provider, model, temperature, max_tokens, system_prompt

    Supported providers: openai, anthropic, gemini, mistral, groq,
                         ollama, openrouter, huggingface

    Usage:
        client = LLMClient()
        response = client.chat("Hello!")
        response = client.chat_with_history([{"role": "user", "content": "Hi"}])
        for chunk in client.stream("Hello!"):
            print(chunk, end="", flush=True)
    """

    def __init__(self):
        config = _load_config()

        self.provider      = config["provider"]
        self.model         = config["model"] or _PROVIDER_DEFAULTS.get(self.provider)
        self.temperature   = config["temperature"]
        self.max_tokens    = config["max_tokens"]
        self.system_prompt = config["system_prompt"]
        self._api_key      = config["api_key"]

        if self.model is None:
            raise ValueError(
                f"Unknown provider '{self.provider}'.\n"
                f"Supported: {list(_PROVIDER_DEFAULTS.keys())}"
            )

        self._backend = self._init_backend()

    def _init_backend(self):
        """Initialize the provider SDK client."""
        p = self.provider

        if p == "openai":
            from openai import OpenAI
            return OpenAI(api_key=self._api_key)

        elif p == "anthropic":
            from anthropic import Anthropic
            return Anthropic(api_key=self._api_key)

        elif p == "gemini":
            import google.generativeai as genai
            genai.configure(api_key=self._api_key)
            return genai.GenerativeModel(
                model_name=self.model,
                system_instruction=self.system_prompt,
                generation_config={
                    "temperature": self.temperature,
                    "max_output_tokens": self.max_tokens,
                },
            )

        elif p == "mistral":
            from mistralai import Mistral
            return Mistral(api_key=self._api_key)

        elif p == "groq":
            from groq import Groq
            return Groq(api_key=self._api_key)

        elif p == "ollama":
            # Ollama exposes an OpenAI-compatible local server
            from openai import OpenAI
            return OpenAI(api_key="ollama", base_url="http://localhost:11434/v1")

        elif p == "openrouter":
            from openai import OpenAI
            return OpenAI(
                api_key=self._api_key,
                base_url="https://openrouter.ai/api/v1",
                default_headers={
                    "HTTP-Referer": "https://github.com/your-project",
                    "X-Title": "LLM Integration",
                },
            )

        elif p == "huggingface":
            from huggingface_hub import InferenceClient
            return InferenceClient(token=self._api_key)

        else:
            raise ValueError(
                f"Unknown provider '{p}'.\n"
                f"Supported: {list(_PROVIDER_DEFAULTS.keys())}"
            )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_messages(self, message: str) -> list[dict]:
        """Wrap a single user string into the messages list format."""
        return [{"role": "user", "content": message}]

    def _prepend_system(self, messages: list[dict]) -> list[dict]:
        """Prepend system prompt if not already in the messages list."""
        if self.system_prompt and not any(m.get("role") == "system" for m in messages):
            return [{"role": "system", "content": self.system_prompt}] + messages
        return messages

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def chat(self, message: str) -> str:
        """
        Send a single message and return the assistant's reply.

        Args:
            message (str): The user's message.

        Returns:
            str: The assistant's response text.
        """
        return self.chat_with_history(self._build_messages(message))

    def chat_with_history(self, messages: list[dict]) -> str:
        """
        Send a full conversation history and return the assistant's reply.

        Args:
            messages: List of {"role": "user"|"assistant"|"system", "content": "..."}

        Returns:
            str: The assistant's response text.
        """
        p = self.provider

        # --- OpenAI-compatible providers (openai, groq, ollama, openrouter) ---
        if p in ("openai", "groq", "ollama", "openrouter"):
            messages = self._prepend_system(messages)
            response = self._backend.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
            return response.choices[0].message.content

        # --- Anthropic ---
        elif p == "anthropic":
            # Anthropic requires system prompt as a top-level argument, not in messages
            filtered = [m for m in messages if m.get("role") != "system"]
            response = self._backend.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                system=self.system_prompt,
                messages=filtered,
            )
            return response.content[0].text

        # --- Gemini ---
        elif p == "gemini":
            # Gemini uses role "model" (not "assistant") and "parts" (not "content")
            history = []
            for m in messages[:-1]:
                role = "model" if m["role"] == "assistant" else m["role"]
                if role in ("user", "model"):   # skip system — handled in GenerativeModel
                    history.append({"role": role, "parts": [m["content"]]})
            chat = self._backend.start_chat(history=history)
            response = chat.send_message(messages[-1]["content"])
            return response.text

        # --- Mistral ---
        elif p == "mistral":
            messages = self._prepend_system(messages)
            response = self._backend.chat.complete(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
            return response.choices[0].message.content

        # --- HuggingFace ---
        elif p == "huggingface":
            messages = self._prepend_system(messages)
            response = self._backend.chat_completion(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
            return response.choices[0].message.content

    def stream(self, message: str):
        """
        Stream the response token by token.

        Yields:
            str: Each text chunk as it arrives.

        Usage:
            for chunk in client.stream("Hello!"):
                print(chunk, end="", flush=True)
            print()
        """
        p = self.provider
        messages = self._prepend_system(self._build_messages(message))

        # --- OpenAI-compatible providers ---
        if p in ("openai", "groq", "ollama", "openrouter"):
            response = self._backend.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                stream=True,
            )
            for chunk in response:
                delta = chunk.choices[0].delta.content
                if delta:
                    yield delta

        # --- Anthropic ---
        elif p == "anthropic":
            filtered = [m for m in messages if m.get("role") != "system"]
            with self._backend.messages.stream(
                model=self.model,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                system=self.system_prompt,
                messages=filtered,
            ) as stream:
                for text in stream.text_stream:
                    yield text

        # --- Gemini ---
        elif p == "gemini":
            history = []
            user_messages = [m for m in messages if m.get("role") != "system"]
            for m in user_messages[:-1]:
                role = "model" if m["role"] == "assistant" else m["role"]
                history.append({"role": role, "parts": [m["content"]]})
            chat = self._backend.start_chat(history=history)
            response = chat.send_message(user_messages[-1]["content"], stream=True)
            for chunk in response:
                if chunk.text:
                    yield chunk.text

        # --- Mistral ---
        elif p == "mistral":
            stream = self._backend.chat.stream(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
            for event in stream:
                delta = event.data.choices[0].delta.content
                if delta:
                    yield delta

        # --- HuggingFace ---
        elif p == "huggingface":
            stream = self._backend.chat_completion(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                stream=True,
            )
            for chunk in stream:
                delta = chunk.choices[0].delta.content
                if delta:
                    yield delta


# ---------------------------------------------------------------------------
# Demo — run directly to test your setup
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("Loading config from .env and llm_config.yaml ...")
    client = LLMClient()
    print(f"Provider : {client.provider}")
    print(f"Model    : {client.model}")
    print("-" * 40)

    # Single-turn
    response = client.chat("Say hello in one sentence.")
    print("chat():", response)
    print("-" * 40)

    # Multi-turn
    history = [
        {"role": "user",      "content": "My name is Alex."},
        {"role": "assistant", "content": "Nice to meet you, Alex!"},
        {"role": "user",      "content": "What is my name?"},
    ]
    print("chat_with_history():", client.chat_with_history(history))
    print("-" * 40)

    # Streaming
    print("stream(): ", end="")
    for chunk in client.stream("Count from 1 to 5."):
        print(chunk, end="", flush=True)
    print()
